import re
import math
from decimal import Decimal

class Calculos:
    def __init__(self, a, b, t, c, func):
        # Inicialização da classe Calculos
        self.a = float(a)  # Limite inferior da integração
        self.b = float(b)  # Limite superior da integração
        self.t = int(t)    # Número de trapézios
        self.dec = int(c)  # Número de casas decimais para arredondamento
        self.func = func   # Função a ser integrada

    def f(self, x):
        # Função para calcular o valor da função em um ponto x
        func_text = self.func.replace("x", str(x))  # Substitui 'x' pelo valor de x na função
        # Substitui símbolos especiais pelos equivalentes em Python
        func_text = re.sub("|".join(["√", "log10", "log", "π", "sen"]),
                           lambda x: {"log10": "log10", "log": "log", "√": "sqrt", "π": "pi", "sen": "sin"}[x.group()],
                           func_text)
        return eval(func_text)  # Avalia a expressão da função em um ponto x

    def calcular(self):
        # Método para calcular a integral pelo Método do Trapézio
        h = (self.b - self.a) / self.t  # Tamanho de cada subintervalo do trapezio
        x = [self.a + i * h for i in range(self.t + 1)]  # Pontos x de cada trapézio
        area = sum([self.f(x[i]) + self.f(x[i + 1]) for i in range(self.t)]) * h / 2  # Fórmula da área

        # Cálculo do erro de arredondamento
        unidadeErro = 0.5 / 10 ** (self.dec)  # Unidade de erro para o número de casas decimais
        erro = unidadeErro * self.t * h  # Erro de arredondamento

        # Calculo do intervalo
        intervalo_min = area - erro
        intervalo_max = area + erro

        #Respostas
        resposta = "x \t f(x)"  #tabela
        for i in range(self.t + 1):
            resposta += f"\n{round(x[i], self.dec)}\t{round(self.f(x[i]), self.dec)}"  # Linhas da tabela

        resposta += f"\nÁrea Total: {round(area, self.dec)}"  # Área total calculada
        resposta += f"\nErro de arredondamento: {round(Decimal(erro), self.dec + 1)}"  # Erro de arredondamento
        resposta += f"\nIntervalo: [{round(Decimal(intervalo_min), self.dec)}, {round(Decimal(intervalo_max), self.dec)}]"  # Intervalo 
        resposta += f"\nAltura do trapezio: {round(h, self.t)}" # Altura do trapezio
        return resposta

#  Usuario insere os valores:
a = input("Insira o valor de a: ")
b = input("Insira o valor de b: ")
t = input("Insira o número de trapézios: ")
c = input("Insira o número de casas decimais: ")
func = input("Insira a função (em termos de x): ")

calculadora = Calculos(a, b, t, c, func)  # Criando um objeto Calculos
resultado = calculadora.calcular()  # Chamando o método calcular
print(resultado)  # Imprimindo o resultado
